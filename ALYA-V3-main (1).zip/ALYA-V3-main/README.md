<img
src="https://i.imgur.com/1SwrtZ1.jpeg" alt="banner">

<h1 align="center">
  <img src="https://i.imgur.com/EPgCOnR.jpeg" width="22px" alt="icon">
  𝐀𝐥𝐲𝐚 𝐂𝐡𝐚𝐧 🐱🎀 - 𝐌𝐞𝐬𝐬𝐞𝐧𝐠𝐞𝐫 𝐁𝐨𝐭
</h1>

<p align="center">
	<a href="https://nodejs.org/dist/v16.20.0">
		<img src="https://img.shields.io/badge/Nodejs%20Support-16.x-brightgreen.svg?style=flat-square" alt="Nodejs Support v16.x">
	</a>
  <img alt="size" src="https://img.shields.io/github/repo-size/ntkhang03/Goat-Bot-V2.svg?style=flat-square&label=size">
  <img alt="code-version" src="https://img.shields.io/badge/dynamic/json?color=brightgreen&label=code%20version&prefix=v&query=%24.version&url=https://github.com/ntkhang03/Goat-Bot-V2/raw/main/package.json&style=flat-square">
  <img alt="visitors" src="https://visitor-badge.laobi.icu/badge?style=flat-square&page_id=ntkhang3.ALYA-Bot-V1.7">
  <img alt="size" src="https://img.shields.io/badge/license-MIT-green?style=flat-square&color=brightgreen">
</p>



The author of this Bot is Masachika Kuze. This fork is maintained by: 𝐀 𝐑 𝐈 𝐉 𝐈 𝐓⚡  

If you find any issues, please report them!


𝐅𝐚𝐜𝐞𝐛𝐨𝐨𝐤: <a href="https://fb.com/arijit016" style="color: black;">𝐀 𝐑 𝐈 𝐉 𝐈 𝐓</a></h3></div>

<p align="center"><a href="fb link" target="_blank" rel="noopener noreferrer">
  <img src="https://i.imgur.com/A0Ve0p4.jpeg" width="100" style="margin-right: 10px;"></a>
</p>
<h5 align="center">
>𝐀 𝐑 𝐈 𝐉 𝐈 𝐓⚡
</h5>

 

<div align="center">
			<h3>Gmail:
			<a href="arijitnaha2@gmail.com" style="color: green;">𝐀 𝐑 𝐈 𝐉 𝐈 𝐓 </a>
				<br>
	𝐅𝐚𝐜𝐞𝐛𝐨𝐨𝐤: <a href="https://fb.com/arijit016" style="color: black;">𝐀 𝐑 𝐈 𝐉 𝐈 𝐓</a></h3></div>

<img align="center" src="https://i.imgur.com/pVS6nuV.jpeg"/>


🔹𝐀 𝐑 𝐈 𝐉 𝐈 𝐓⚡
